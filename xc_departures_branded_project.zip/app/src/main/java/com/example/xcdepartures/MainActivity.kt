
package com.example.xcdepartures

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XCDeparturesApp() }
    }
}

private val XCBrand = Color(0xFFD10A47)
private val XCCream = Color(0xFFE8E0D2)
private val XCTeal = Color(0xFF33C7CF)
private val XCYellow = Color(0xFFF2B000)

@Composable
fun XCDeparturesApp() {
    var selectedStation by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(
        primary = XCBrand,
        secondary = XCTeal,
        tertiary = XCYellow,
        background = XCCream,
        surface = Color.White
    )) {
        if (selectedStation == null) {
            HomeScreen { selectedStation = it }
        } else {
            DepartureBoardScreen(selectedStation!!) { selectedStation = null }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenBoard: (String) -> Unit) {
    var stationCode by remember { mutableStateOf("") }
    val favourites = listOf("BHM", "BRI", "MANPIC", "GLC", "EXD", "LDS")
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("XC Departures", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = XCBrand,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = XCCream
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(XCCream)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.xc_logo),
                            contentDescription = "CrossCountry logo",
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = stationCode,
                            onValueChange = { stationCode = it.uppercase() },
                            label = { Text("Station CRS code e.g. BHM") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { if (stationCode.isNotBlank()) onOpenBoard(stationCode.trim()) },
                            colors = ButtonDefaults.buttonColors(containerColor = XCBrand),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Open Departure Board") }
                    }
                }
            }
            item { PromoCard("Travel Information", XCTeal) }
            item { PromoCard("Engineering Works", XCYellow) }
            item { Text("Quick favourites", style = MaterialTheme.typography.titleLarge) }
            items(favourites) { code ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenBoard(code) },
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Text(code, modifier = Modifier.padding(18.dp), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
fun PromoCard(title: String, bg: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = bg)) {
        Box(Modifier.fillMaxWidth().height(140.dp).padding(20.dp), contentAlignment = Alignment.BottomStart) {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = Color.Black)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepartureBoardScreen(stationCode: String, onBack: () -> Unit) {
    val boardUrl = "https://tiger.worldline.global/$stationCode/mobile"
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Departures: $stationCode") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XCBrand, titleContentColor = Color.White)
            )
        }
    ) { padding ->
        WebViewScreen(boardUrl, Modifier.padding(padding).fillMaxSize())
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(url: String, modifier: Modifier = Modifier) {
    AndroidView(modifier = modifier, factory = { context ->
        WebView(context).apply {
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            loadUrl(url)
        }
    })
}
